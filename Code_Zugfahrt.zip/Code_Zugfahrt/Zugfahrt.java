public class Zugfahrt
{
    private String von;
    private String nach;
    private int dauer;
    private boolean fahrrad;

    public Zugfahrt()
    {
        setVon("Wien");
        setNach("Salzburg");
        setDauer(240);
        setFahrrad(true);
    }

    public Zugfahrt(String von, String nach, int dauer, boolean fahrrad)
    {
        setVon(von);
        setNach(nach);
        setDauer(dauer);
        setFahrrad(fahrrad);
    }

    public void setVon(String von)
    {
        this.von = von;
    }

    public void setNach(String nach)
    {
        this.nach = nach;
    }

    public void setDauer(int dauer)
    {
        this.dauer = dauer;
    }

    public void setFahrrad(boolean fahrrad)
    {
        this.fahrrad = fahrrad;
    }

    public String getVon()
    {
        return von;
    }

    public String getNach()
    {
        return nach;
    }

    public int getDauer()
    {
        return dauer;
    }

    public boolean getFahrrad()
    {
        return fahrrad;
    }

    public void printZugfahrt()
    {
        System.out.println("Zugfahrt:\t" + von + "\t" + nach + "\t" + dauer + "\t" + fahrrad);
    }
}
