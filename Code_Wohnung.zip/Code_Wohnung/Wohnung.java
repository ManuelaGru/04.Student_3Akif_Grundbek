public class Wohnung
{
    private String ort;
    private int preis;
    private int zimmer;
    private boolean balkon;

    public Wohnung()
    {
        setOrt("Wien");
        setPreis(200000);
        setZimmer(4);
        setBalkon(true);
    }

    public Wohnung(String ort, int preis, int zimmer, boolean balkon)
    {
        setOrt(ort);
        setPreis(preis);
        setZimmer(zimmer);
        setBalkon(balkon);
    }

    public void setOrt(String ort)
    {
        this.ort = ort;
    }

    public void setPreis(int preis)
    {
        this.preis = preis;
    }

    public void setZimmer(int zimmer)
    {
        this.zimmer = zimmer;
    }

    public void setBalkon(boolean balkon)
    {
        this.balkon = balkon;
    }

    public String getOrt()
    {
        return ort;
    }

    public int getPreis()
    {
        return preis;
    }

    public int getZimmer()
    {
        return zimmer;
    }

    public boolean getBalkon()
    {
        return balkon;
    }

    public void printWohnung()
    {
        System.out.println("Wohnung:\t" + ort + "\t" + preis + "\t" + zimmer + "\t" + balkon);
    }
}
